package samplejdbcconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Sybase db deki byte array datayı postgre db deki ayni tablo ve alana migrate eder.
 * Basit bir java JDBC connection ornegidir.
 * @author arif.erol
 */
public class SampleJDBCConnection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        Connection connSybase = null;
        Connection connPostgre = null;
        Statement stmtSybase = null;
        ResultSet rsSybase = null;
        try {
            connSybase = DriverManager.getConnection("jdbc:sybase:Tds:192.168.0.1:2638", "username", "password");
            connPostgre = DriverManager.getConnection("jdbc:postgresql://192.168.0.1:5432/db_name", "username", "password");
            stmtSybase = connSybase.createStatement();
            rsSybase = stmtSybase.executeQuery("select id, bytefieldname from schemaname.table_name where id = 5;");
            PreparedStatement stmtPostgre = connPostgre.prepareStatement("update schemaname.table_name set bytefieldname = ? where id = ? ;");
            while (rsSybase.next()) {
                long id = rsSybase.getLong(1);
                byte[] logoByteArray = rsSybase.getBytes(2);
                stmtPostgre.setBytes(1, logoByteArray);
                stmtPostgre.setLong(2, id);
                stmtPostgre.addBatch();
                System.out.println("Islem yapilan id = " + id);
            }
            int[] result = stmtPostgre.executeBatch();
//            connPostgre.commit();/*Auto commit aktif degilse acilacak*/
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            rsSybase.close();
            connPostgre.close();
            connSybase.close();
        }
    }

}
